import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  return NextResponse.json(
    { error: 'တရားဝင်ရလဒ်ရင်းမြစ် မချိတ်ဆက်ရသေးသောကြောင့် ဂိမ်းရလဒ်/settlement ကို ယာယီပိတ်ထားပါသည်။' },
    { status: 410, headers: { 'Cache-Control': 'no-store' } },
  );
}
