import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST() {
  return NextResponse.json(
    { error: 'ငွေပါသောဂိမ်းလောင်းကြေးကို တရားဝင် result နှင့် settlement မချိတ်ဆက်မချင်း ယာယီရပ်နားထားပါသည်။' },
    { status: 410, headers: { 'Cache-Control': 'no-store' } },
  );
}
