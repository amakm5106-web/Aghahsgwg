'use client';

import React, { useMemo, useState } from 'react';
import { AlertCircle, ArrowDownCircle, ArrowUpCircle, CheckCircle2, Clock3, Copy, RefreshCw, Wallet } from 'lucide-react';
import type { PaymentRequest, ProviderConnection, User } from '@/lib/store';

interface WalletViewProps {
  currentUser: User;
  initialTab?: 'deposit' | 'withdraw';
  requests: PaymentRequest[];
  providers: ProviderConnection[];
  onCreateDeposit: (phone: string, transferId: string) => Promise<{ message?: string }>;
  onCreateWithdrawal: (amountMMK: number, phone: string) => Promise<{ message?: string }>;
  onRefresh?: () => Promise<unknown>;
}

type Notice = { kind: 'success' | 'error'; text: string } | null;

const formatMMK = (amount: number) => `${Math.max(0, amount).toLocaleString()} MMK`;
const statusText: Record<PaymentRequest['status'], string> = {
  pending: 'စစ်ဆေးဆဲ',
  approved: 'အတည်ပြုပြီး',
  rejected: 'ပယ်ချထားသည်',
};

export const WalletView: React.FC<WalletViewProps> = ({
  currentUser,
  initialTab = 'deposit',
  requests,
  providers,
  onCreateDeposit,
  onCreateWithdrawal,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw' | 'history'>(initialTab);
  const [senderPhone, setSenderPhone] = useState('');
  const [transferId, setTransferId] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawPhone, setWithdrawPhone] = useState('');
  const [notice, setNotice] = useState<Notice>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedProvider, setCopiedProvider] = useState<string | null>(null);
  const availableBalance = Number(currentUser.wallet_balance) || 0;
  const reservedBalance = Number(currentUser.reserved_balance) || 0;
  const myRequests = useMemo(
    () => requests.filter((request) => String(request.user_id) === String(currentUser.id)),
    [requests, currentUser.id],
  );

  const copyReceiver = async (provider: ProviderConnection) => {
    try {
      await navigator.clipboard.writeText(provider.receiver_phone);
      setCopiedProvider(provider.code);
      window.setTimeout(() => setCopiedProvider(null), 1600);
    } catch {
      setNotice({ kind: 'error', text: 'ဖုန်းနံပါတ်ကို ကူးယူ၍မရပါ။ ကိုယ်တိုင်ကူးယူပါ။' });
    }
  };

  const submitDeposit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setNotice(null);
    setIsSubmitting(true);
    try {
      const result = await onCreateDeposit(senderPhone, transferId);
      setNotice({ kind: 'success', text: result.message || 'ငွေသွင်းတောင်းဆိုမှုကို စစ်ဆေးရန်ပေးပို့ပြီးပါပြီ။' });
      setSenderPhone('');
      setTransferId('');
    } catch (error) {
      setNotice({ kind: 'error', text: (error as Error).message || 'တောင်းဆိုမှုကို ပေးပို့၍မရပါ။' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const submitWithdrawal = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setNotice(null);
    const amount = Number(withdrawAmount.replace(/[ ,]/g, ''));
    setIsSubmitting(true);
    try {
      const result = await onCreateWithdrawal(amount, withdrawPhone);
      setNotice({ kind: 'success', text: result.message || 'ငွေထုတ်တောင်းဆိုမှုကို စာရင်းသွင်းပြီးပါပြီ။' });
      setWithdrawAmount('');
      setWithdrawPhone('');
    } catch (error) {
      setNotice({ kind: 'error', text: (error as Error).message || 'ငွေထုတ်တောင်းဆိုမှု မအောင်မြင်ပါ။' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const tabs = [
    { id: 'deposit' as const, label: 'ငွေသွင်း', icon: ArrowDownCircle },
    { id: 'withdraw' as const, label: 'ငွေထုတ်', icon: ArrowUpCircle },
    { id: 'history' as const, label: 'တောင်းဆိုမှုများ', icon: Clock3 },
  ];

  return (
    <main className="wallet-page mx-auto w-full max-w-5xl space-y-5 px-3 pb-24 pt-4 sm:px-5 sm:pt-6">
      <section className="wallet-balance-card rounded-3xl p-5 text-white shadow-lg sm:p-7">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="flex items-center gap-2 text-sm font-semibold text-white/75"><Wallet className="h-4 w-4" /> ရရှိနိုင်သောလက်ကျန်</p>
            <p className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">{formatMMK(availableBalance)}</p>
            {reservedBalance > 0 && <p className="mt-2 text-xs text-white/75">စစ်ဆေးဆဲငွေထုတ် reserve: {formatMMK(reservedBalance)}</p>}
          </div>
          {onRefresh && <button type="button" onClick={() => void onRefresh().catch(() => undefined)} className="wallet-quiet-button"><RefreshCw className="h-4 w-4" /> ပြန်စစ်ရန်</button>}
        </div>
        <div className="wallet-tabs mt-6 grid grid-cols-3 gap-2 rounded-2xl p-1">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button key={id} type="button" onClick={() => { setActiveTab(id); setNotice(null); }} className={`wallet-tab ${activeTab === id ? 'is-active' : ''}`}>
              <Icon className="h-4 w-4" /><span>{label}</span>
            </button>
          ))}
        </div>
      </section>

      {notice && <div role="status" aria-live="polite" className={`wallet-notice ${notice.kind}`}>
        {notice.kind === 'success' ? <CheckCircle2 className="h-5 w-5 shrink-0" /> : <AlertCircle className="h-5 w-5 shrink-0" />}
        <span>{notice.text}</span>
      </div>}

      {activeTab === 'deposit' && <div className="grid gap-5 lg:grid-cols-[1fr_0.8fr]">
        <section className="wallet-panel">
          <div className="mb-5">
            <p className="wallet-kicker">DEPOSIT REQUEST</p>
            <h1 className="wallet-heading">ငွေသွင်းတောင်းဆိုရန်</h1>
            <p className="mt-2 text-sm leading-6 text-stone-600">လွှဲပြီးသားငွေကို စစ်ဆေးနိုင်ရန် ဖုန်းနံပါတ်နှင့် ငွေလွှဲ ID ကိုသာ ဖြည့်ပါ။ စီမံခန့်ခွဲသူက ငွေလွှဲကိုစစ်ဆေးပြီး အတည်ပြုမှသာ wallet ထဲသို့ ထည့်ပေးမည်။</p>
          </div>
          <form onSubmit={submitDeposit} className="space-y-4">
            <label className="wallet-field">
              <span>လွှဲသူဖုန်းနံပါတ်</span>
              <input inputMode="tel" autoComplete="tel" value={senderPhone} onChange={(event) => setSenderPhone(event.target.value)} placeholder="09xxxxxxxxx" required maxLength={24} />
            </label>
            <label className="wallet-field">
              <span>ငွေလွှဲ ID</span>
              <input autoComplete="off" value={transferId} onChange={(event) => setTransferId(event.target.value)} placeholder="လွှဲပြေစာရှိ ID အပြည့်အစုံ" required minLength={5} maxLength={128} />
              <small>ငွေပမာဏကို ဒီ form တွင် မဖြည့်ရပါ။ Transfer ID ထပ်နေပါက request ကို လက်မခံပါ။</small>
            </label>
            <button type="submit" className="wallet-primary-button w-full" disabled={isSubmitting}>
              {isSubmitting ? 'ပေးပို့နေသည်…' : 'စစ်ဆေးရန် တင်သွင်းမည်'}
            </button>
          </form>
        </section>
        <aside className="space-y-4">
          <section className="wallet-panel">
            <p className="wallet-kicker">RECEIVER ACCOUNTS</p>
            <h2 className="wallet-heading text-xl">တရားဝင်လက်ခံအကောင့်များ</h2>
            {providers.length === 0 ? <p className="mt-3 rounded-2xl border border-dashed border-stone-300 bg-stone-50 p-4 text-sm leading-6 text-stone-600">လက်ခံအကောင့်ကို Admin Dashboard မှ မသတ်မှတ်ရသေးပါ။ ငွေမလွှဲမီ အကောင့်အချက်အလက်ကို စစ်ဆေးပါ။</p> : <div className="mt-4 space-y-3">
              {providers.filter((provider) => provider.status === 'active').map((provider) => <div key={provider.code} className="wallet-receiver-card">
                <div className="min-w-0"><p className="text-xs font-bold uppercase tracking-wide text-[#7A1F2B]">{provider.name}</p><p className="mt-1 truncate text-lg font-bold text-stone-900">{provider.receiver_phone}</p><p className="text-sm text-stone-600">{provider.receiver_name}</p></div>
                <button type="button" onClick={() => void copyReceiver(provider)} className="wallet-copy-button" aria-label={`${provider.name} ဖုန်းနံပါတ်ကူးယူရန်`}><Copy className="h-4 w-4" />{copiedProvider === provider.code ? 'ကူးပြီး' : 'ကူးရန်'}</button>
              </div>)}
            </div>}
          </section>
          <div className="wallet-manual-note"><Clock3 className="mt-0.5 h-4 w-4 shrink-0" /><p>ငွေလွှဲကို အလိုအလျောက်စစ်ဆေးသည့် provider API မချိတ်ထားပါ။ Request သည် pending အဖြစ်မှတ်တမ်းဝင်ပြီး admin က ပြင်ပစာရင်းနှင့်စစ်ဆေးပါမည်။</p></div>
        </aside>
      </div>}

      {activeTab === 'withdraw' && <section className="wallet-panel mx-auto w-full max-w-2xl">
        <p className="wallet-kicker">WITHDRAWAL REQUEST</p>
        <h1 className="wallet-heading">ငွေထုတ်တောင်းဆိုရန်</h1>
        <p className="mt-2 text-sm leading-6 text-stone-600">တောင်းဆိုထားသော amount ကို စစ်ဆေးနေစဉ် reserve လုပ်ထားမည်။ ပြင်ပငွေလွှဲပြီး reference ကို အတည်ပြုပြီးမှသာ paid အဖြစ်သတ်မှတ်ပါမည်။</p>
        <div className="wallet-available-strip mt-4"><span>လက်ရှိရနိုင်သောလက်ကျန်</span><strong>{formatMMK(availableBalance)}</strong></div>
        <form onSubmit={submitWithdrawal} className="mt-5 space-y-4">
          <label className="wallet-field"><span>ငွေထုတ်ပမာဏ (MMK)</span><input inputMode="numeric" value={withdrawAmount} onChange={(event) => setWithdrawAmount(event.target.value)} placeholder="ဥပမာ 10000" required /></label>
          <label className="wallet-field"><span>လက်ခံမည့်ဖုန်းနံပါတ်</span><input inputMode="tel" autoComplete="tel" value={withdrawPhone} onChange={(event) => setWithdrawPhone(event.target.value)} placeholder="09xxxxxxxxx" required maxLength={24} /></label>
          <button type="submit" className="wallet-primary-button w-full" disabled={isSubmitting || availableBalance < 1000}>{isSubmitting ? 'ပေးပို့နေသည်…' : 'ငွေထုတ်တောင်းဆိုရန်'}</button>
        </form>
      </section>}

      {activeTab === 'history' && <section className="wallet-panel">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3"><div><p className="wallet-kicker">REQUEST HISTORY</p><h1 className="wallet-heading">ငွေသွင်း/ထုတ်တောင်းဆိုမှုများ</h1></div><span className="wallet-count-pill">{myRequests.length} ခု</span></div>
        {myRequests.length === 0 ? <div className="wallet-empty"><Clock3 className="h-7 w-7" /><p>ငွေသွင်း/ထုတ်တောင်းဆိုမှု မရှိသေးပါ။</p></div> : <div className="space-y-3">
          {myRequests.map((request) => <article key={request.id} className="wallet-request-row">
            <span className={`wallet-request-icon ${request.kind}`} aria-hidden="true">{request.kind === 'deposit' ? <ArrowDownCircle className="h-5 w-5" /> : <ArrowUpCircle className="h-5 w-5" />}</span>
            <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><strong>{request.kind === 'deposit' ? 'ငွေသွင်း' : 'ငွေထုတ်'}</strong><span className={`wallet-status ${request.status}`}>{statusText[request.status]}</span></div><p className="mt-1 text-sm text-stone-600">{request.kind === 'deposit' ? `Transfer ID: ${request.txn_id || '—'}` : `လက်ခံဖုန်း: ${request.account_number || '—'}`}</p><p className="mt-1 text-xs text-stone-500">{request.created_at ? new Date(request.created_at).toLocaleString('my-MM') : ''}{request.admin_note ? ` · ${request.admin_note}` : ''}</p></div>
            <div className="text-right"><strong className="whitespace-nowrap text-sm">{request.amount === null ? 'စစ်ဆေးပြီးမှ' : formatMMK(request.amount)}</strong></div>
          </article>)}
        </div>}
      </section>}
    </main>
  );
};
