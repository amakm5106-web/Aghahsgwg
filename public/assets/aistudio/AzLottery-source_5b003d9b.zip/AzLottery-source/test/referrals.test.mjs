import test from 'node:test';
import assert from 'node:assert/strict';
import { createReferralCode, maskIdentifier } from '../lib/referrals/server.ts';

test('referral code is opaque, uppercase, and URL-safe', () => {
  const code = createReferralCode();
  assert.match(code, /^AZ[A-F0-9]{12}$/);
});

test('team identifiers are masked before being returned to agents', () => {
  assert.equal(maskIdentifier('09712345678', 'phone'), '09••••78');
  assert.equal(maskIdentifier('alice@example.com', 'email'), 'a•••@example.com');
});
