import test from 'node:test';
import assert from 'node:assert/strict';
import { isSameOriginRequest } from '../lib/auth/origin.ts';

const makeRequest = (headers = {}) => new Request('https://lottery.example/api/wave', {
  method: 'POST',
  headers: { host: 'lottery.example', ...headers },
});

test('same-site is not trusted when Origin belongs to a sibling subdomain', () => {
  assert.equal(isSameOriginRequest(makeRequest({
    'sec-fetch-site': 'same-site',
    origin: 'https://attacker.lottery.example',
  })), false);
});

test('same-site without an Origin or Referer is rejected', () => {
  assert.equal(isSameOriginRequest(makeRequest({ 'sec-fetch-site': 'same-site' })), false);
});

test('same-site with the application origin is allowed', () => {
  assert.equal(isSameOriginRequest(makeRequest({
    'sec-fetch-site': 'same-site',
    origin: 'https://lottery.example',
  })), true);
});
