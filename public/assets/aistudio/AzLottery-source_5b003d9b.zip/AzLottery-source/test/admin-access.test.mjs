import test from 'node:test';
import assert from 'node:assert/strict';
import { isAdminIdentifier } from '../lib/auth/admin-access.ts';

test('allowlisted email is the sole admin identity', () => {
  assert.equal(isAdminIdentifier('primren685@gmail.com', 'email'), true);
  assert.equal(isAdminIdentifier(' PRIMREN685@GMAIL.COM ', 'email'), true);
});

test('other emails and phone identifiers do not receive admin access', () => {
  assert.equal(isAdminIdentifier('other@example.com', 'email'), false);
  assert.equal(isAdminIdentifier('primren685@gmail.com', 'phone'), false);
  assert.equal(isAdminIdentifier('primren685@gmail.com.evil@example.com', 'email'), false);
});
