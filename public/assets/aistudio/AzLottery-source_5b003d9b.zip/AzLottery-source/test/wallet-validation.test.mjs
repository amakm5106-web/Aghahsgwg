import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizePhone, normalizeTransferId, parseMmkAmount, parseProviderCode } from '../lib/wallet/validation.ts';
import { numberFromDb } from '../lib/wallet/server.ts';

test('normalizes Myanmar phone numbers to the 09 local format', () => {
  assert.equal(normalizePhone('၀၉ ၄၂၀-၁၂၃၄၅၆'), '09420123456');
  assert.equal(normalizePhone('+95 9 420 123456'), '09420123456');
  assert.equal(normalizePhone('959420123456'), '09420123456');
});

test('rejects malformed or non-Myanmar phone values', () => {
  assert.throws(() => normalizePhone('12345'));
  assert.throws(() => normalizePhone('091234'));
  assert.throws(() => normalizePhone(null));
});

test('normalizes and bounds complete transaction references', () => {
  assert.equal(normalizeTransferId('  ab-123  '), 'AB-123');
  assert.throws(() => normalizeTransferId('1234'));
  assert.throws(() => normalizeTransferId('abc/12345'));
  assert.throws(() => normalizeTransferId('A'.repeat(129)));
});

test('accepts only integer MMK amounts within the configured range', () => {
  assert.equal(parseMmkAmount('၁၀,၀၀၀'.replace(',', '')), 10000);
  assert.equal(parseMmkAmount(1000), 1000);
  assert.equal(parseMmkAmount(100000000), 100000000);
  assert.throws(() => parseMmkAmount(999));
  assert.throws(() => parseMmkAmount(1000.5));
  assert.throws(() => parseMmkAmount('1e5'));
});

test('restricts provider code to the configured payment rails', () => {
  assert.equal(parseProviderCode('wave'), 'wave');
  assert.throws(() => parseProviderCode('other'));
});

test('does not silently coerce unsafe database money values to zero', () => {
  assert.equal(numberFromDb('0'), 0);
  assert.equal(numberFromDb('10000'), 10000);
  assert.throws(() => numberFromDb('9007199254740992'), /safe integer precision/);
});
