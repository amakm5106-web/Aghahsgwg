import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  console.error('DATABASE_URL is required to apply database migrations.');
  process.exitCode = 1;
} else {
  const connection = await mysql.createConnection({ uri: databaseUrl, timezone: 'Z' });
  try {
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS azlottery_schema_migrations (
        version VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
        applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (version)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    const migrationDirectory = path.join(projectRoot, 'migrations');
    const files = (await readdir(migrationDirectory))
      .filter((name) => /^\d+.*\.sql$/.test(name))
      .sort((left, right) => left.localeCompare(right));

    for (const filename of files) {
      const [existing] = await connection.execute(
        'SELECT version FROM azlottery_schema_migrations WHERE version = ? LIMIT 1',
        [filename],
      );
      if (existing.length) {
        console.log(`Already applied: ${filename}`);
        continue;
      }

      const source = await readFile(path.join(migrationDirectory, filename), 'utf8');
      const statements = source.split(/;\s*(?:\r?\n|$)/).map((sql) => sql.trim()).filter(Boolean);
      for (const sql of statements) await connection.execute(sql);
      await connection.execute(
        'INSERT INTO azlottery_schema_migrations (version) VALUES (?)',
        [filename],
      );
      console.log(`Applied: ${filename}`);
    }
  } finally {
    await connection.end();
  }
}
